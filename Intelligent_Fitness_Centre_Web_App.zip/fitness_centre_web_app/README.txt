INTELLIGENT FITNESS CENTRE MANAGEMENT SUITE - WEB APP

Requirements:
- Python 3.10 or newer
- Internet connection for first-time Flask installation

Run on Windows:
1. Extract this ZIP.
2. Open the extracted folder in VS Code.
3. Open Terminal in VS Code.
4. Run: py -m pip install -r requirements.txt
5. Run: py app.py
6. Open the address shown in the terminal (usually http://127.0.0.1:5000).

Features included:
- Dashboard and member statistics
- Add, validate, search, update and delete member records
- Membership fee calculation (Basic ₹500/month, Premium ₹1000/month)
- SQLite database storage
- Lambda-based sorting/filtering
- Recursive member counting

Note:
This is an educational local demo. Change app.secret_key before any real deployment.
