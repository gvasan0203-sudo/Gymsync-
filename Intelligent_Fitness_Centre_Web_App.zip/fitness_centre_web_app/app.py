from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
DB_PATH = Path(__file__).with_name("fitness_centre.db")

BASIC_FEE = 500
PREMIUM_FEE = 1000


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS members (
                member_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                age INTEGER NOT NULL,
                phone TEXT NOT NULL,
                membership TEXT NOT NULL,
                duration INTEGER NOT NULL,
                fee INTEGER NOT NULL
            )
        """)


def calculate_fee(membership, duration=1):
    """Return the total fee. Default duration is one month."""
    rates = {"basic": BASIC_FEE, "premium": PREMIUM_FEE}
    return rates.get(membership.strip().lower(), 0) * duration


def validate_member(member_id, name, age_text, phone, membership, duration_text):
    member_id = member_id.strip()
    name = name.strip()
    phone = phone.strip()
    membership = membership.strip().lower()

    if not member_id:
        return None, "Member ID cannot be empty."
    if not name or not name.replace(" ", "").isalpha():
        return None, "Name must contain letters and spaces only."
    try:
        age = int(age_text)
    except (TypeError, ValueError):
        return None, "Age must be a whole number."
    if not 18 <= age <= 100:
        return None, "Age must be between 18 and 100."
    if not phone.isdigit() or len(phone) != 10:
        return None, "Phone number must contain exactly 10 digits."
    if membership not in ("basic", "premium"):
        return None, "Choose Basic or Premium membership."
    try:
        duration = int(duration_text)
    except (TypeError, ValueError):
        return None, "Duration must be a whole number."
    if not 1 <= duration <= 36:
        return None, "Duration must be between 1 and 36 months."

    return {
        "member_id": member_id,
        "name": name.title(),
        "age": age,
        "phone": phone,
        "membership": membership,
        "duration": duration,
        "fee": calculate_fee(membership, duration=duration)
    }, None


def recursive_member_count(records):
    """Recursive operation used by the dashboard report."""
    if not records:
        return 0
    return 1 + recursive_member_count(records[1:])


@app.route("/")
def dashboard():
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM members ORDER BY member_id").fetchall()
    records = [dict(row) for row in rows]
    total = recursive_member_count(records)
    premium_count = len(list(filter(lambda m: m["membership"] == "premium", records)))
    total_revenue = sum(m["fee"] for m in records)
    return render_template(
        "index.html",
        members=records,
        total=total,
        premium_count=premium_count,
        total_revenue=total_revenue,
        query=""
    )


@app.route("/add", methods=["POST"])
def add_member():
    data, error = validate_member(
        request.form.get("member_id", ""),
        request.form.get("name", ""),
        request.form.get("age", ""),
        request.form.get("phone", ""),
        request.form.get("membership", ""),
        request.form.get("duration", "")
    )
    if error:
        flash(error, "error")
        return redirect(url_for("dashboard"))

    try:
        with get_db() as conn:
            conn.execute("""
                INSERT INTO members
                (member_id, name, age, phone, membership, duration, fee)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                data["member_id"], data["name"], data["age"], data["phone"],
                data["membership"], data["duration"], data["fee"]
            ))
        flash("Member registered successfully.", "success")
    except sqlite3.IntegrityError:
        flash("That Member ID already exists. Please use a different ID.", "error")

    return redirect(url_for("dashboard"))


@app.route("/search")
def search_members():
    query = request.args.get("q", "").strip()
    with get_db() as conn:
        rows = conn.execute("""
            SELECT * FROM members
            WHERE member_id LIKE ? OR name LIKE ?
            ORDER BY member_id
        """, (f"%{query}%", f"%{query}%")).fetchall()
    records = [dict(row) for row in rows]
    return render_template(
        "index.html",
        members=records,
        total=len(records),
        premium_count=sum(1 for m in records if m["membership"] == "premium"),
        total_revenue=sum(m["fee"] for m in records),
        query=query
    )


@app.route("/update/<member_id>", methods=["GET", "POST"])
def update_member(member_id):
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM members WHERE member_id = ?", (member_id,)
        ).fetchone()

    if row is None:
        flash("Member not found.", "error")
        return redirect(url_for("dashboard"))

    member = dict(row)
    if request.method == "POST":
        data, error = validate_member(
            member_id,
            request.form.get("name", ""),
            request.form.get("age", ""),
            request.form.get("phone", ""),
            request.form.get("membership", ""),
            request.form.get("duration", "")
        )
        if error:
            flash(error, "error")
            return redirect(url_for("update_member", member_id=member_id))

        with get_db() as conn:
            conn.execute("""
                UPDATE members
                SET name=?, age=?, phone=?, membership=?, duration=?, fee=?
                WHERE member_id=?
            """, (
                data["name"], data["age"], data["phone"], data["membership"],
                data["duration"], data["fee"], member_id
            ))
        flash("Member details updated.", "success")
        return redirect(url_for("dashboard"))

    return render_template("update.html", member=member)


@app.route("/delete/<member_id>", methods=["POST"])
def delete_member(member_id):
    with get_db() as conn:
        conn.execute("DELETE FROM members WHERE member_id = ?", (member_id,))
    flash("Member record deleted.", "success")
    return redirect(url_for("dashboard"))


@app.route("/sort")
def sort_members():
    sort_by = request.args.get("by", "name")
    allowed = {"name", "age", "fee"}
    if sort_by not in allowed:
        sort_by = "name"
    with get_db() as conn:
        rows = conn.execute("SELECT * FROM members").fetchall()
    records = [dict(row) for row in rows]
    records.sort(key=lambda member: member[sort_by])  # lambda sorting
    return render_template(
        "index.html",
        members=records,
        total=len(records),
        premium_count=sum(1 for m in records if m["membership"] == "premium"),
        total_revenue=sum(m["fee"] for m in records),
        query=""
    )


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
